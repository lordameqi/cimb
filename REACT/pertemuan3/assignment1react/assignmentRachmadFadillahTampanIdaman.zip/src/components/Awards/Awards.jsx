import { Component } from "react";


class Awards extends Component{
    render(){
        return(
            <div className="widget card">
            <div className="card-body">
                <div className="widget-content">
                    <h5 className="widget-title card-title">Awards<br/> &<br/> Certifications</h5>
                    <p><b>Juara 2</b> <br/> Hackathon TechConnect by Sinarmas Mining </p>
                </div>
            </div>
        </div>
        )
    }
}

export default Awards;