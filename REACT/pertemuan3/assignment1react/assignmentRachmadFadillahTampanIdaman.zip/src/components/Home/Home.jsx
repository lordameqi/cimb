import { Component } from "react";
import About from '../About/About';


class Home extends Component{
render(){
    return( 
    <div>

    <About/>
    </div>
    )
};
}


export default Home;