import { Component } from "react";

class Interest extends Component{
    render(){
        return(
            <div className="widget card">
            <div className="card-body">
                <div className="widget-content">
                    <h5 className="widget-title card-title">INTERESTS</h5>
                    <p>Video games</p>
                    <p>Finance</p>
                    <p>Basketball</p>
                    <p>Theatre</p>
                </div>
            </div>
        </div>
        )
    }
}

export default Interest;