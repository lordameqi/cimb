package day11.assignment1_RachmadFadillah;

public class Latihan5a {
    public static void main(String[] args) {
        int y1, y2, X1, X2;
        y1 = 2;
        y2 = 2;
        X1 = (y1 + y2) * (y1 + y2);
        X2 = (y1 % 4) * y2;
        // point a
        System.out.println("Nilai X1 = " + X1);
        System.out.println("Nilai X2 = " + X2);

    }
}
