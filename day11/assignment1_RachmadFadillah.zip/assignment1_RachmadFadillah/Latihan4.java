package day11.assignment1_RachmadFadillah;

public class Latihan4 {
    public static void main(String[] args) {
        // Buat variabel
        int a = 10;
        int b = 8;
        int c = 12;
        int d = 5;

        // Hasil
        System.out.println("Tes ke 1 = " + (a > d));
        System.out.println("Tes ke 2 = " + (a < c));
        System.out.println("Tes ke 3 = " + (a >= d));
        System.out.println("Tes ke 4 = " + (d <= b));
        System.out.println("Tes ke 5 = " + (a == (d + d)));
        System.out.println("Tes ke 6 = " + (a != b));// sqs
        System.out.println("Tes ke 7 = " + (d > b));
        System.out.println("Tes ke 8 = " + (c <= a));
        System.out.println("Tes ke 9 = " + (b == d));
        System.out.println("Tes ke 10 = " + (a != (d + d)));
    }
}
