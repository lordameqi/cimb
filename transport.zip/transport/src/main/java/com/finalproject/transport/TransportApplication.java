package com.finalproject.transport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.finalproject.transport.entity.bus.*;
import com.finalproject.transport.entity.user.*;
import com.finalproject.transport.repository.*;

@SpringBootApplication
public class TransportApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransportApplication.class, args);
	}

	@Bean
	CommandLineRunner init(RoleRepository roleRepository, UserRepository userRepository,
			StopRepository stopRepository, AgencyRepository agencyRepository,
			BusRepository busRepository, TripRepository tripRepository,
			TripScheduleRepository tripScheduleRepository) {

		return args -> {

			// Isi tabel role
			Role adminRole = roleRepository.findByRole(UserRole.ADMIN);
			if (adminRole == null) {
				adminRole = new Role();
				adminRole.setRole(UserRole.ADMIN);
				roleRepository.save(adminRole);
			}

			Role userRole = roleRepository.findByRole(UserRole.PASSENGER);
			if (userRole == null) {
				userRole = new Role();
				userRole.setRole(UserRole.PASSENGER);
				roleRepository.save(userRole);
			}

			// Isi user dengan admin
			User admin = userRepository.findByEmail("nanda.thareq@gmail.com");
			if (admin == null) {
				admin = new User();
				admin.setEmail("nanda.thareq@gmail.com");
				admin.setPassword("$2a$10$7PtcjEnWb/ZkgyXyxY1/Iei2dGgGQUbqIIll/dt.qJ8l8nQBWMbYO"); // "123456"
				admin.setFirstName("Nanda");
				admin.setLastName("Thareq");
				admin.setMobileNumber("08234325434");
				admin.setRoles(Arrays.asList(adminRole));
				userRepository.save(admin);
			}

			// Isi user dengan passenger
			User passenger = userRepository.findByEmail("ucup.supra@gmail.com");
			if (passenger == null) {
				passenger = new User();
				passenger.setEmail("ucup.supra@gmail.com");
				passenger.setPassword("$2a$10$7PtcjEnWb/ZkgyXyxY1/Iei2dGgGQUbqIIll/dt.qJ8l8nQBWMbYO"); // "123456"
				passenger.setFirstName("Ucup");
				passenger.setLastName("Supra");
				passenger.setMobileNumber("08023534568");
				passenger.setRoles(Arrays.asList(userRole));
				userRepository.save(passenger);
			}

			// isi tabel stop
			Stop stopA = stopRepository.findByCode("GWN");
			if (stopA == null) {
				stopA = new Stop();
				stopA.setName("Terminal Giwangan");
				stopA.setDetail("Kota Yogyakarta");
				stopA.setCode("GWN");
				stopRepository.save(stopA);
			}

			Stop stopB = stopRepository.findByCode("CHM");
			if (stopB == null) {
				stopB = new Stop();
				stopB.setName("Terminal Cicaheum");
				stopB.setDetail("Kota Bandung");
				stopB.setCode("CHM");
				stopRepository.save(stopB);
			}

			Stop stopC = stopRepository.findByCode("PBG");
			if (stopC == null) {
				stopC = new Stop();
				stopC.setName("Terminal Pulogebang");
				stopC.setDetail("Kota Jakarta");
				stopC.setCode("PBG");
				stopRepository.save(stopC);
			}

			Stop stopD = stopRepository.findByCode("BRH");
			if (stopD == null) {
				stopD = new Stop();
				stopD.setName("Terminal Bungurasih");
				stopD.setDetail("Kota Surabaya");
				stopD.setCode("BRH");
				stopRepository.save(stopD);
			}

			// Isi tabel agen
			Agency agencyA = agencyRepository.findByCode("SJY");
			if (agencyA == null) {
				agencyA = new Agency();
				agencyA.setName("Sinar Jaya");
				agencyA.setCode("SJY");
				agencyA.setDetails("Reaching desitnations with ease");
				agencyA.setOwner(admin);
				agencyRepository.save(agencyA);
			}

			// Create a bus
			Bus busA = busRepository.findByCode("SJY-01");
			if (busA == null) {
				busA = new Bus();
				busA.setCode("SJY-01");
				busA.setAgency(agencyA);
				busA.setCapacity(60);
				busRepository.save(busA);
			}

			// Add busA to set of buses owned by Agency 'AGENCYA'
			if (agencyA.getBuses() == null) {
				List<Bus> buses = new ArrayList<>();
				agencyA.setBuses(buses);
				agencyA.getBuses().add(busA);
				agencyRepository.save(agencyA);
			}

			// Create a Trip
			Trip trip = tripRepository.findBySourceStopAndDestStopAndBus(stopA, stopB, busA);
			if (trip == null) {
				trip = new Trip();
				trip.setSourceStop(stopA);
				trip.setDestStop(stopB);
				trip.setBus(busA);
				trip.setAgency(agencyA);
				trip.setFare(100);
				trip.setJourneyTime(60);
				tripRepository.save(trip);
			}

			// Create a trip schedule
			TripSchedule tripSchedule = tripScheduleRepository.findByTripDetailAndTripDate(trip, "2022-10-15");
			if (tripSchedule == null) {
				tripSchedule = new TripSchedule();
				tripSchedule.setTripDetail(trip);
				tripSchedule.setTripDate("2022-10-15");
				tripSchedule.setAvailableSeats(trip.getBus().getCapacity());
				tripScheduleRepository.save(tripSchedule);
			}
		};

	}
}
