package com.finalproject.transport.entity.user;

public enum UserRole {
    
    ADMIN, PASSENGER
    
}
