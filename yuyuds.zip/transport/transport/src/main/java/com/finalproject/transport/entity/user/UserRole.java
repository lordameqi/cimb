/*
 * Copyright (c) 2022. Made by Rachmad Fadillah
 */

package com.finalproject.transport.entity.user;

public enum UserRole {
    
    ADMIN, PASSENGER
    
}
