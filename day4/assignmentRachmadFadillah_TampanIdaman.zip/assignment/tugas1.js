const keyAsli = "passport";
var password = prompt("Masukkan password anda");

if (keyAsli != password) {
    alert("Salah");
    window.location.href = "https://www.semrush.com/blog/javascript-redirect/";
}else{ 
    alert("Benar");
}
